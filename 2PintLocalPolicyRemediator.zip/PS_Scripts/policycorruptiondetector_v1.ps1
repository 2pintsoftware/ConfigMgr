﻿<# 
   .SYNOPSIS 
    Check for local Policy corruption issue

   .DESCRIPTION
   Checks the local policy files for corruption Then remediates if found

   .ACKs TO this blog - we took this and ran with it..
   https://itinlegal.wordpress.com/2017/09/09/psa-locating-badcorrupt-registry-pol-files/


   .NOTES
    AUTHOR: 2Pint Software
    EMAIL: support@2pintsoftware.com
    VERSION: 1.0.0.0
    DATE:07/03/2018 
    
    CHANGE LOG: 
    1.0.0.0 : 07/03/2018  : Initial version of script 

   .LINK
    https://2pintsoftware.com

#>

Function TimeStamp {$(Get-Date -UFormat "%D %T")}
$logfile = "$env:temp\2PintLocalPolicyCheck.log"

#Main Function which checks the policy files for corruption
Function Test-IsRegistryPOLGood
    {
       $PathToMachineRegistryPOLFile = "$ENV:Windir\System32\GroupPolicy\Machine\Registry.pol"
       $PathToUserRegistryPOLFile = "$ENV:Windir\System32\GroupPolicy\User\Registry.pol"


       # Test for a Machine policy file - if there isn't one - all good
        if(!(Test-Path -Path $PathToMachineRegistryPOLFile -PathType Leaf)) {}
        #If there is a .pol file - test it
        else{
        If (((Get-Content -Encoding Byte -Path $PathToMachineRegistryPOLFile -TotalCount 4) -join '') -ne '8082101103'){Return $False}
        }

        # Test for a User policy file - if there isn't one - as you were
        if(!(Test-Path -Path $PathToUserRegistryPOLFile -PathType Leaf)) {}
        #If there is a .pol file - test it
        else {
        If (((Get-Content -Encoding Byte -Path $PathToUserRegistryPOLFile -TotalCount 4) -join '') -ne '8082101103'){Return $False}
        }
      #if we made it here alles gut
       return $true
    }
  
#Set the default
$Compliance = "Compliant"  
   
#Then test the policy file using the function above - returns non-compliant if EITHER machine/user policy file is found to be corrupt.
If ((Test-IsRegistryPOLGood) -eq $true)
{
$Compliance = "Compliant"
}
else
{
   $Compliance = "Non-Compliant"
}

$(TimeStamp) + " Local Policy Check Returned: " + $Compliance  | Out-File -FilePath $Logfile -Append -Encoding ascii
$Compliance

