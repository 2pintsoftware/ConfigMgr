﻿<# 
   .SYNOPSIS 
    Check for local Policy corruption issue

   .DESCRIPTION
   Checks the local policy files for corruption Then remediates if found

   .ACKs TO this blog - we just added the user part..
   https://itinlegal.wordpress.com/2017/09/09/psa-locating-badcorrupt-registry-pol-files/


   .NOTES
    AUTHOR: 2Pint Software
    EMAIL: support@2pintsoftware.com
    VERSION: 1.0.0.0
    DATE:07/03/2018 
    
    CHANGE LOG: 
    1.0.0.0 : 07/03/2018  : Initial version of script 

   .LINK
    https://2pintsoftware.com

#>

Function TimeStamp {$(Get-Date -UFormat "%D %T")}

$Logfile = "$PSScriptRoot\PolicyRemediator.log"

$PathToMachineRegistryPOLFile = "$ENV:Windir\System32\GroupPolicy\Machine\Registry.pol"
$PathToUserRegistryPOLFile = "$ENV:Windir\System32\GroupPolicy\User\Registry.pol"

 

#----------------------------------------------------------- 
#Check both Local Policy files and if corrupt - remove them
#-----------------------------------------------------------     
       $(TimeStamp) + " Checking local policy integrity" | Out-File -FilePath $Logfile -Append -Encoding ascii



       # Test for a Machine policy file - if there isn't one - all good
        if(!(Test-Path -Path $PathToMachineRegistryPOLFile -PathType Leaf)) {}
        #If there is a .pol file - test it
        else{
        If (((Get-Content -Encoding Byte -Path $PathToMachineRegistryPOLFile -TotalCount 4) -join '') -ne '8082101103')
        {
        $(TimeStamp) + " Removing corrupt Machine Policy file" | Out-File -FilePath $Logfile -Append -Encoding ascii
        Try {
            ri $PathToMachineRegistryPOLFile -Confirm:$false -ErrorAction SilentlyContinue
            }
        Catch {
              $(TimeStamp) + " Failed to remove policy file - Exiting" + (Write-Error -Message $_) | Out-File -FilePath $Logfile -Append -Encoding ascii
              Exit 1
              }
        }
           }

        # Test for a User policy file - if there isn't one - as you were
        if(!(Test-Path -Path $PathToUserRegistryPOLFile -PathType Leaf)) {}
        #If there is a .pol file - test it
        else {
        If (((Get-Content -Encoding Byte -Path $PathToUserRegistryPOLFile -TotalCount 4) -join '') -ne '8082101103')
        {
        $(TimeStamp) + " Removing corrupt User Policy file" | Out-File -FilePath $Logfile -Append -Encoding ascii
        Try {
            ri $PathToUserRegistryPOLFile -Confirm:$false -ErrorAction SilentlyContinue
            }
        Catch {
              $(TimeStamp) + " Failed to remove user policy file - Exiting" + (Write-Error -Message $_) | Out-File -FilePath $Logfile -Append -Encoding ascii
              Exit 1
              }
        }
            }

#----------------------------------------------------------- 
#END - Local Policy check
#----------------------------------------------------------- 

